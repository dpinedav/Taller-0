package Modificacion;

public class Main {

	private static final String LoaderOlimpicos = null;

	public static <CalculadoraEstadisticas> void main(String[] args) {
		System.out.println("Hola Mundo!");
		CalculadoraEstadisticas calc = LoaderOlimpicos.cargarArchivo("./data/atletas.csv");
		System.out.println(((Object) calc).paisConMasMedallistas());
	}

}
